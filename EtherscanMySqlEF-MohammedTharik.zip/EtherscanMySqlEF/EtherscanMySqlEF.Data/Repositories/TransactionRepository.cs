﻿using EtherscanMySqlEF.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace EtherscanMySqlEF.Data.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly EtScanContext _ctx;
        public TransactionRepository(EtScanContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<IEnumerable<Transaction>> GetTransactionAsync()
        {
            var Transaction = await _ctx.Transaction.ToListAsync();
            return Transaction;
        }

        public async Task<Transaction> GetTransactionByIdAsync(int id)
        {
            return await _ctx.Transaction.FindAsync(id);
        }

        public async Task<Transaction> CreateTransactionAsync(Transaction Transaction)
        {
            _ctx.Transaction.Add(Transaction);
            await _ctx.SaveChangesAsync();
            return Transaction;
        }

        public async Task UpdateTransactionAsync(Transaction Transaction)
        {
            _ctx.Transaction.Update(Transaction);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteTransactionAsync(Transaction Transaction)
        {
            _ctx.Transaction.Remove(Transaction);
            await _ctx.SaveChangesAsync();
        }


        public List<Transaction> CreateOrUpdateTransactionsAsync(List<Transaction> lstTransactions)
        {
            //_ctx.Transaction.Add(Transaction);
            //await _ctx.SaveChangesAsync();
            //return Transaction;


            foreach (var transaction in lstTransactions)
            {
                // Check if the record already exists in the database based on some condition
                var existingTransaction = _ctx.Transaction.FirstOrDefault(t => t.hash == transaction.hash);

                if (existingTransaction == null)
                {
                    // Create new record
                    _ctx.Transaction.Add(transaction);
                }
            }

            _ctx.SaveChanges();

            return lstTransactions;
        }

    }
}
