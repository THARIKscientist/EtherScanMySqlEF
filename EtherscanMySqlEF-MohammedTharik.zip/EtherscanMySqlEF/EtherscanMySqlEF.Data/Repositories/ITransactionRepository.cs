﻿using EtherscanMySqlEF.Data.Models;

namespace EtherscanMySqlEF.Data.Repositories
{
    public interface ITransactionRepository
    {
        Task<Transaction> CreateTransactionAsync(Transaction Transaction);
        Task DeleteTransactionAsync(Transaction Transaction);
        Task<IEnumerable<Transaction>> GetTransactionAsync();
        Task<Transaction> GetTransactionByIdAsync(int id);
        Task UpdateTransactionAsync(Transaction Transaction);

        List<Transaction> CreateOrUpdateTransactionsAsync(List<Transaction> lstTransactions);
    }
}