﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace EtherscanMySqlEF.Data.Models
{
    public class EtScanContext : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        public EtScanContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = configuration.GetConnectionString("default");
        }
        public DbSet<Transaction> Transaction { get; set; }
        public DbSet<Parameter> Parameter { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(_connectionString);
        }

    }
}
