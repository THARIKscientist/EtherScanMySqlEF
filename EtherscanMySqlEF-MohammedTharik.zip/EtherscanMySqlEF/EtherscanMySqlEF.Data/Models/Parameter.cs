﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EtherscanMySqlEF.Data.Models
{
    [Table("Parameter")]
    public class Parameter
    {
        public int Id { get; set; }
        [Required]
        public string? module { get; set; }

        [Required]
        public string? action { get; set; }

        [Required]
        public string? address { get; set; }

        [Required]
        public string? apikey { get; set; }

        [Required]
        public int startblock { get; set; }

        [Required]
        public int endblock { get; set; }

        [Required]
        public int page { get; set; }

        [Required]
        public int offset { get; set; }

        [Required]
        public string? sort { get; set; }

    }
}
