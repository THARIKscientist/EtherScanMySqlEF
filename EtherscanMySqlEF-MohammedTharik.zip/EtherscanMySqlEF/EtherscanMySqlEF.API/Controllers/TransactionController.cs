﻿using EtherscanMySqlEF.Data.Models;
using EtherscanMySqlEF.Data.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EtherscanMySqlEF.API.Data;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Principal;
using System;

namespace EtherscanMySqlEF.API.Controllers
{
    [Route("api/Transaction")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepository _TransactionRepo;
        private readonly ILogger<TransactionController> _logger;
        public TransactionController(ITransactionRepository TransactionRepo, ILogger<TransactionController> logger)
        {
            _TransactionRepo = TransactionRepo;
            _logger = logger;
            
        }

        [HttpPost]
        public async Task<IActionResult> FetchTransaction(Parameter param)
        {
            try
            {
                //Todo fetch data from API ethernet

                string Url = "https://api.etherscan.io/api";

                //sample URL
                //https://api.etherscan.io/api
                // ? module = account
                // & action = txlist
                // & address = 0x119f079871594e9FFc22D9453785C9E9364F2bCe
                // & startblock = 0
                // & endblock = 99999999
                // & page = 1
                // & offset = 10
                // & sort = asc
                // & apikey = DIGH4F2IPQD3TMRFTTH1F6ZDTIYIR8UWTQ

                string apiUrl = $"{Url}?module={param.module}&action={param.action}&address={param.address}&startblock={param.startblock}&endblock={param.endblock}&page={param.page}&offset={param.offset}&sort={param.sort}&apikey={param.apikey}";
                List<Transaction> lstTransaction = new List<Transaction>();
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string json = await response.Content.ReadAsStringAsync();
                        var result = JObject.Parse(json);

                        if (result["status"].ToString() == "1")
                        {
                            lstTransaction = result["result"].ToObject<List<Transaction>>();
                        }
                        else
                        {
                            Console.WriteLine($"Error: {result["message"]}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Error: {response.StatusCode}");
                    }
                }

                var retLstTransactions =  _TransactionRepo.CreateOrUpdateTransactionsAsync(lstTransaction);
                return CreatedAtAction(nameof(FetchTransaction), retLstTransactions);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        
    }
}
