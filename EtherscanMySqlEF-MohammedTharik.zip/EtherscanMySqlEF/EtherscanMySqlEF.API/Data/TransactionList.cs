﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using EtherscanMySqlEF.Data.Models;
using EtherscanMySqlEF.Data.Repositories;

namespace EtherscanMySqlEF.API.Data
{
    public class TransactionList
    {
        //static async Task Main()
        //{
        //    string apiUrl = "https://api.etherscan.io/api?module=account&action=txlist&address=YourAddress&apikey=YourAPIKey";

        //    List<Transaction> transactions = await GetTransactions(apiUrl);

        //    // Now 'transactions' list contains the response data.
        //    foreach (var transaction in transactions)
        //    {
        //        Console.WriteLine($"Transaction Hash: {transaction.Hash}, Value: {transaction.Value}");
        //    }
        //}

        public static async Task<List<Transaction>> FetchTransactions()
        {
            string apiUrl = "https://api.etherscan.io/api?module=account&action=txlist&address=0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD&apikey=DIGH4F2IPQD3TMRFTTH1F6ZDTIYIR8UWTQ";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    var result = JObject.Parse(json);

                    if (result["status"].ToString() == "1")
                    {
                        return result["result"].ToObject<List<Transaction>>();
                    }
                    else
                    {
                        Console.WriteLine($"Error: {result["message"]}");
                    }
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                }

                return new List<Transaction>();
            }
        }
    }
}
